function AggandGrowthcase1
syms n0 x y  b h t

n0(x)=exp(-x);
G(x)=x;
b(x,y)=1;                                             

m0(t)=2/(2+t);
m1(t)=exp(t);
n(t,x)=((m0(t))^2/m1(t))*exp((-m0(t)/m1(t))*x);

R1(t,x)=diff(G(x).*n0(x),x)-1/2.*(int(b(x-y,y).*n0(x-y).*n0(y),y,[0,x]))+n0(x)*(int(b(x,y).*n0(y),y,[0,inf]));
n1(h,t,x)=h.*int(R1(t,x),t,[0,t])

R2(t,x)=diff(n1(h,t,x),t)+diff(G(x).*n1(h,t,x),x)-1/2.*(int(b(x-y,y).*(n0(x-y) ...
    .*n1(h,t,y)+n1(h,t,x-y).*n0(y)),y,[0,x]))+n0(x).*(int(b(x,y).*n1(h,t,y),y,[0,inf]))+n1(h,t,x)*(int(b(x,y).*n0(y),y,[0,inf]));
n2(h,t,x)=n1(h,t,x)+h.*int(R2(t,x),t,[0,t])

R3(t,x)=diff(n2(h,t,x),t)+diff(G(x).*n2(h,t,x),x)-1/2.*(int(b(x-y,y).*(n0(x-y) ...
    .*n2(h,t,y)+n2(h,t,x-y).*n0(y)+n1(h,t,x-y).*n1(h,t,y)),y,[0,x]))+n0(x).*(int(b(x,y) ...
    .*n2(h,t,y),y,[0,inf]))+n2(h,t,x)*(int(b(x,y).*n0(y),y,[0,inf]))+n1(h,t,x)*(int(b(x,y).*n1(h,t,y),y,[0,inf]));
n3(h,t,x)=n2(h,t,x)+h.*int(R3(t,x),t,[0,t])

R4(t,x)=diff(n3(h,t,x),t)+diff(G(x).*n3(h,t,x),x)-1/2.*(int(b(x-y,y).*(n0(x-y) ...
    .*n3(h,t,y)+n3(h,t,x-y).*n0(y)+n1(h,t,x-y).*n2(h,t,y)+n2(h,t,x-y).*n1(h,t,y)),y,[0,x]) ...
    )+n0(x).*(int(b(x,y).*n3(h,t,y),y,[0,inf]))+n3(h,t,x)*(int(b(x,y).*n0(y),y,[0,inf]))+n1(h,t,x ...
    )*(int(b(x,y).*n2(h,t,y),y,[0,inf]))+n2(h,t,x)*(int(b(x,y).*n1(h,t,y),y,[0,inf]));
n4(h,t,x)=n3(h,t,x)+h.*int(R4(t,x),t,[0,t]);

R5(t,x)=diff(n4(h,t,x),t)+diff(G(x).*n4(h,t,x),x)-1/2.*(int(b(x-y,y).*(n0(x-y) ...
    .*n4(h,t,y)+n4(h,t,x-y).*n0(y)+n1(h,t,x-y).*n3(h,t,y)+n2(h,t,x-y).*n2(h,t,y)+n3(h,t,x-y).*n1(h,t,y)),y,[0,x]) ...
    )+n0(x).*(int(b(x,y).*n4(h,t,y),y,[0,inf]))+n4(h,t,x)*(int(b(x,y).*n0(y),y,[0,inf]))+n1(h,t,x ...
    )*(int(b(x,y).*n3(h,t,y),y,[0,inf]))+n2(h,t,x)*(int(b(x,y).*n2(h,t,y),y,[0,inf]))+n3(h,t,x)*(int(b(x,y).*n1(h,t,y),y,[0,inf]));
n5(h,t,x)=n4(h,t,x)+h.*int(R5(t,x),t,[0,t]);

R6(t,x)=diff(n5(h,t,x),t)+diff(G(x).*n5(h,t,x),x)-1/2.*(int(b(x-y,y).*(n0(x-y) ...
    .*n5(h,t,y)+n5(h,t,x-y).*n0(y)+n1(h,t,x-y).*n4(h,t,y)+n2(h,t,x-y).*n3(h,t,y)+n3(h,t,x-y).*n2(h,t,y)+n4(h,t,x-y).*n1(h,t,y)),y,[0,x]) ...
    )+n0(x).*(int(b(x,y).*n5(h,t,y),y,[0,inf]))+n1(h,t,x ...
    )*(int(b(x,y).*n4(h,t,y),y,[0,inf]))+n2(h,t,x)*(int(b(x,y).*n3(h,t,y),y,[0,inf]))+n3(h,t,x)*(int(b(x,y).*n2(h,t,y),y,[0,inf]))+n4(h,t,x ...
    )*(int(b(x,y).*n1(h,t,y),y,[0,inf]))+n5(h,t,x)*(int(b(x,y).*n0(y),y,[0,inf]));
n6(h,t,x)=n5(h,t,x)+h.*int(R6(t,x),t,[0,t]);

sol(h,t,x)=n0(x)+n1(h,t,x)+n2(h,t,x)+n3(h,t,x)+n4(h,t,x)+n5(h,t,x)+n6(h,t,x);

figure(1)
fplot(sol(h,1,0.5)/n0(0.5),[-1.5,0.5], '-k*', 'LineWidth', 1, 'MarkerSize', 8)
xlabel('c0')
ylabel('particle density')
grid on



% figure(2)
% fplot(n(1,x),[10^-5,10])
% hold on
% fplot(sol(-0.75,1,x),[10^-5,10])
% fplot(sol(-0.5,1,x),[10^-5,10])
% fplot(sol(-1,1,x),[10^-5,10])
% legend('exact', '1','2','3')
% hold off



%Moment Caluclation%

M0ham(t)= int(sol(-0.75,t,x),x,[0,inf]);
M1ham(t)= int(x.*sol(-0.75,t,x),x,[0,inf]);
M2ham(t)= int((x.^2).*sol(-0.75,t,x),x,[0,inf]);

M0hpm(t)= int(sol(-1,t,x),x,[0,inf]);
M1hpm(t)= int(x.*sol(-1,t,x),x,[0,inf]);
M2hpm(t)= int((x.^2).*sol(-1,t,x),x,[0,inf]);



M0(t)= int(n(t,x),x,[0,inf]);
M1(t)= int(x.*n(t,x),x,[0,inf]);
M2(t)= int((x.^2).*n(t,x),x,[0,inf]);





x_bound=CreateLogarithmicGrids(10^(-9),50,31);
x               =   (x_bound(1:end-1) + x_bound(2:end)) / 2;
dx              =   x_bound(2:end) - x_bound(1:end-1);

time_end        =   1;
TimeSteps       =   11;  
time            =   linspace(0, time_end, TimeSteps);
ClassNumbers      =   length(x);

n0 = n0(x);
sol_disc = sol(-0.75,1,x).*dx;
Exact_disc = n(1,x).*dx;
HPM_disc = sol(-1,1,x).*dx;

data = xlsread('AggandGrowth');
rawTable1 = readtable('AggandGrowth','Sheet','Ex5');
 
xxl=rawTable1.size;
xdis_CAT=rawTable1.distribution.*dx';

txl=rawTable1.time;
M0_CAT=rawTable1.m0;
M1_CAT=rawTable1.m1./1.116170982;


figure(3)
%loglog(x(1:ClassNumbers), n0(end,1:ClassNumbers), 'k--', 'LineWidth', 1, 'MarkerSize', 8)       %Initial Data
loglog(x(1:ClassNumbers), Exact_disc(end,1:ClassNumbers), 'k', 'LineWidth', 1, 'MarkerSize', 8)
hold on
loglog(x(1:ClassNumbers), sol_disc(end,1:ClassNumbers), 'r^', 'LineWidth', 1, 'MarkerSize', 9)     % T=5
loglog(x(1:ClassNumbers), HPM_disc(end,1:ClassNumbers), 'kv', 'LineWidth', 1, 'MarkerSize', 8) % T=3
loglog(xxl, xdis_CAT, 'b*', 'LineWidth', 1, 'MarkerSize', 9)
legend('Exact','HAM','HPM', 'CAT')
xlabel('dimensionless size of representative')
ylabel('particle density')
grid on
hold off

M0_Exact           =   M0(time)./m0(0);
M1_Exact           =   M1(time)./m1(0);
M2_Exact           =  M2(time);

M0_HAM             =   M0ham(time)./m0(0);
M1_HAM             =   M1ham(time)./m1(0);
M2_HAM             =  M2ham(time);

M0_HPM             =   M0hpm(time)./m0(0);
M1_HPM             =   M1hpm(time)./m1(0);
M2_HPM             =  M2hpm(time);


% figure(4)
% plot(time, M0_Exact, 'k','LineWidth', 1, 'MarkerSize', 9)
% hold on
% plot(time, M0_HAM,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M0_HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
% plot(txl, M1_CAT,'b*','LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1_Exact, 'k', 'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1_HAM, 'r^', 'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1_HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
% plot(txl, M0_CAT,'b*','LineWidth', 1, 'MarkerSize', 9)
% legend('Exact', 'HAM', 'HPM',' CAT')
% xlabel('dimensionless time')
% ylabel('normalized moments')
% grid on
% hold off


figure(4)
plot(time, M0_Exact, 'k','LineWidth', 1, 'MarkerSize', 9)
hold on
plot(time, M0_HAM,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
plot(time, M0_HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M0_CAT, 'b*', 'LineWidth', 1, 'MarkerSize', 9)
plot(time, M1_Exact, 'k.-', 'LineWidth', 1, 'MarkerSize', 9)
plot(time, M1_HAM, 'r+', 'LineWidth', 1, 'MarkerSize', 9)
plot(time,M1_HPM, 'kpentagram', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M1_CAT,' bo','LineWidth', 1, 'MarkerSize', 9)
legend('Exact M0', 'HAM M0', 'HPM M0',' CAT M0','Exact M1', 'HAM M1', 'HPM M1',' CAT M1')
xlabel('dimensionless time')
ylabel('normalized moments')
grid on
hold off


% figure(5)
% % plot(time, M1_Exact, 'k', 'LineWidth', 1, 'MarkerSize', 9)
% % hold on
% % plot(time, M1_HAM, 'r*', 'LineWidth', 1, 'MarkerSize', 9)
% % plot(time, M1_HPM, 'ko', 'LineWidth', 1, 'MarkerSize', 9)
% loglog(time, M0_Exact, 'k','LineWidth', 1, 'MarkerSize', 9)
% hold on
% loglog(time, M0_HAM,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
% loglog(time, M0_HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
% legend(' Exact', 'HAM', 'HPM')
% xlabel('dimensionless time')
% ylabel('normalized moments')
% grid on
% hold off

format long
ErrorHAM=double(abs(Exact_disc(end,end)-sol_disc(end,end)))
ErrorHPM=double(abs(Exact_disc(end,end)-HPM_disc(end,end)))
ErrorCAT=double(abs(Exact_disc(end,end)-xdis_CAT))
%Errorpade=double(abs(Exact_disc(end,end)-sol_disc3(end,end)))


%Moement Errors%
format long
M0errorHAM= double(abs(M0_Exact-M0_HAM)./M0_Exact)

M1errorHAM= double(abs(M1_Exact-M1_HAM)./M1_Exact)



format long
M0errorHPM= double(abs(M0_Exact-M0_HPM)./M0_Exact)

M1errorHPM= double(abs(M1_Exact-M1_HPM)./M1_Exact)



M0errorCAT= double(abs(M0_Exact-M0_CAT)./M0_Exact)

M1errorCAT= double(abs(M1_Exact-M1_CAT)./M1_Exact)

