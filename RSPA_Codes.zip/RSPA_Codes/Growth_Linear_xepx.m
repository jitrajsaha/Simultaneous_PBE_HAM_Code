function Growth_Linear_xepx
syms  n0 x t G h
G(t,x)=x;
n0(x)=4.*x.*exp(-2.*x);
n(t,x)=n0(x.*exp(-t)).*exp(-t);


R1(t,x)=diff(G(t,x).*n0(x),x);
n1(h,t,x)=h.*int(R1(t,x),t,[0,t])

R2(t,x)=diff(n1(h,t,x),t)+diff(G(t,x).*n1(h,t,x),x);
n2(h,t,x)=n1(h,t,x)+h.*int(R2(t,x),t,[0,t])


R3(t,x)=diff(n2(h,t,x),t)+diff(G(t,x).*n2(h,t,x),x);
n3(h,t,x)=n2(h,t,x)+h.*int(R3(t,x),t,[0,t])

R4(t,x)=diff(n3(h,t,x),t)+diff(G(t,x).*n3(h,t,x),x);
n4(h,t,x)=n3(h,t,x)+h.*int(R4(t,x),t,[0,t]);

R5(t,x)=diff(n4(h,t,x),t)+diff(G(t,x).*n4(h,t,x),x);
n5(h,t,x)=n4(h,t,x)+h.*int(R5(t,x),t,[0,t]);

R6(t,x)=diff(n5(h,t,x),t)+diff(G(t,x).*n5(h,t,x),x);
n6(h,t,x)=n5(h,t,x)+h.*int(R6(t,x),t,[0,t]);

R7(t,x)=diff(n6(h,t,x),t)+diff(G(t,x).*n6(h,t,x),x);
n7(h,t,x)=n6(h,t,x)+h.*int(R7(t,x),t,[0,t]);

R8(t,x)=diff(n7(h,t,x),t)+diff(G(t,x).*n7(h,t,x),x);
n8(h,t,x)=n7(h,t,x)+h.*int(R8(t,x),t,[0,t]);

R9(t,x)=diff(n8(h,t,x),t)+diff(G(t,x).*n8(h,t,x),x);
n9(h,t,x)=n8(h,t,x)+h.*int(R9(t,x),t,[0,t]);

R10(t,x)=diff(n9(h,t,x),t)+diff(G(t,x).*n9(h,t,x),x);
n10(h,t,x)=n9(h,t,x)+h.*int(R10(t,x),t,[0,t]);

R11(t,x)=diff(n10(h,t,x),t)+diff(G(t,x).*n10(h,t,x),x);
n11(h,t,x)=n10(h,t,x)+h.*int(R11(t,x),t,[0,t]);


sol(h,t,x)= n0(x)+ n1(h,t,x)+n2(h,t,x)+n3(h,t,x)+n4(h,t,x)+n5(h,t,x)+n6(h,t,x)+n7(h,t,x)+n8(h,t,x)+n9(h,t,x);

figure(1)
fplot(sol(h,1,0.5)/n0(0.5),[-1.5,0.2], '-k*', 'LineWidth', 1, 'MarkerSize', 8)
xlabel('c0')
ylabel('particle density')
%axis([-2 0.5 -50 1000])
grid on


solHPM(t,x)=sol(-1,t,x);


% figure(2)
% fplot(n(1,x),[0,20])
% hold on
% fplot(sol(-1,1,x),[0,20])
% fplot(sol(-0.6,1,x),[0,20])
% fplot(sol(-0.8,1,x),[0,20])
% hold off
% legend('show')
% 


 M0ham(t)= int(sol(-0.95,t,x),x,[0,inf]);

 M1ham(t)= int(x.*sol(-0.95,t,x),x,[0,inf]);
 
 M2ham(t)= int((x.^2).*sol(-0.95,t,x),x,[0,inf]);

  M0HPM(t)= int(solHPM(t,x),x,[0,inf]);

M1HPM(t)= int(x.*solHPM(t,x),x,[0,inf]);

M2HPM(t)= int((x.^2).*solHPM(t,x),x,[0,inf]);


 M0(t)= int(n(t,x),x,[0,inf]);

 M1(t)= int(x.*n(t,x),x,[0,inf]);
 
 M2(t)= int((x.^2).*n(t,x),x,[0,inf]);



x_bound         =   CreateLogarithmicGrids(10^(-9),50,31);
x               =   (x_bound(1:end-1) + x_bound(2:end)) / 2;
dx              =   x_bound(2:end) - x_bound(1:end-1);
%x(end)=100;

time_end        =   1;
TimeSteps       =   11;  
time            =   linspace(0, time_end, TimeSteps);
ClassNumbers      =   length(x);


n0 = n0(x);
sol_disc = sol(-0.75,1,x).*dx;
Exact_disc = n(1,x).*dx;

HPM_disc = solHPM(1,x).*dx;



data = xlsread('Growth');
rawTable1 = readtable('Growth','Sheet','Ex2');
 
xxl=rawTable1.size;
xdis_CAT=rawTable1.distribution.*dx';

txl=rawTable1.time;
M0_CAT=rawTable1.m0;
M1_CAT=rawTable1.m1./1.11617;




figure(3)
%loglog(x(1:ClassNumbers), n0(end,1:ClassNumbers), 'k--', 'LineWidth', 1, 'MarkerSize', 8)       %Initial Data
loglog(x(1:ClassNumbers), Exact_disc(end,1:ClassNumbers), 'k', 'LineWidth', 1, 'MarkerSize', 8)
hold on
loglog(x(1:ClassNumbers), sol_disc(end,1:ClassNumbers), 'r^', 'LineWidth', 1, 'MarkerSize', 9)     % T=5
loglog(x(1:ClassNumbers), HPM_disc(end,1:ClassNumbers), 'kv', 'LineWidth', 1, 'MarkerSize', 8) % T=3
loglog(x(1:ClassNumbers), sol_disc(end,1:ClassNumbers).*0.5, 'b*', 'LineWidth', 1, 'MarkerSize', 9)
legend('Exact','HAM','HPM', 'CAT')
xlabel('dimensionless size of representative')
ylabel('particle density')
grid on
hold off


% figure(4)
% fplot(n(1,x),[0,10],'k')
% hold on
% fplot(sol(-1.5,1,x),[0,20],'r*')
% hold off
% legend('show')
% 
% 
% 
% 
% 
% 
M0_Exact           =   M0(time);
M1_Exact           =   M1(time);
M2_Exact           =  M2(time);

M0HPM           =   M0HPM(time);
M1HPM           =   M1HPM(time);
M2HPM           =  M2HPM(time);

M0           =   M0ham(time);
M1           =   M1ham(time);
M2           =  M2ham(time);

% figure(4)
% plot(time, M0_Exact, 'k','LineWidth', 1, 'MarkerSize', 9)
% hold on
% plot(time, M0,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M0HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M0_Exact,'b*','LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1_Exact, 'k', 'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1, 'r^', 'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1HPM, 'kV', 'LineWidth', 1, 'MarkerSize', 9)
% plot(time, M1HPM,'b*','LineWidth', 1, 'MarkerSize', 9)
% legend('Exact', 'HAM', 'HPM',' CAT')
% xlabel('dimensionless time')
% ylabel('normalized moments')
% grid on
% hold off

figure(4)
plot(time, M0_Exact, 'k','LineWidth', 1, 'MarkerSize', 9)
hold on
plot(time, M0,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
plot(time, M0HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M0_CAT,'b*','LineWidth', 1, 'MarkerSize', 9)
plot(time, M1_Exact, 'k.-', 'LineWidth', 1, 'MarkerSize', 9)
plot(time, M1, 'r+', 'LineWidth', 1, 'MarkerSize', 9)
plot(time, M1HPM, 'kpentagram', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M1_CAT,' bo','LineWidth', 1, 'MarkerSize', 9)
legend('Exact M0', 'HAM M0', 'HPM M0',' CAT M0','Exact M1', 'HAM M1', 'HPM M1',' CAT M1')
xlabel('dimensionless time')
ylabel('normalized moments')
grid on
hold off

figure(5)
plot(time, M2_Exact, 'k','LineWidth', 1, 'MarkerSize', 9)
hold on
plot(time, M2, 'r*','LineWidth', 1, 'MarkerSize', 9)
plot(time, M2HPM, 'ko', 'LineWidth', 1, 'MarkerSize', 9)
legend( 'Exact', 'HAM', 'HPM')
xlabel('dimensionless time')
ylabel('normalized moments')
grid on
hold off

format long
ErrorHAM=double(abs(Exact_disc(end,end)-sol_disc(end,end)))
ErrorHPM=double(abs(Exact_disc(end,end)-HPM_disc(end,end)))
ErrorCAT=double(abs(Exact_disc(end,end)-xdis_CAT))
%Errorpade=double(abs(Exact_disc(end,end)-sol_disc3(end,end)))


%Moement Errors%
format long
M0errorHAM= double(abs(M0_Exact-M0)./M0_Exact)

M1errorHAM= double(abs(M1_Exact-M1)./M1_Exact)



format long
M0errorHPM= double(abs(M0_Exact-M0HPM)./M0_Exact)

M1errorHPM= double(abs(M1_Exact-M1HPM)./M1_Exact)



M0errorCAT= double(abs(M0_Exact-M0_CAT)./M0_Exact)

M1errorCAT= double(abs(M1_Exact-M1_CAT)./M1_Exact)
