function x_b = CreateLogarithmicGrids(x_min, x_max, I)

if x_min ==0
    
    x_min = 1e-8;
    
end

x_b  =  exp(linspace(log(x_min), log(x_max), I));

return