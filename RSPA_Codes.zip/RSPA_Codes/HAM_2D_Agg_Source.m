function HAM_2D_Agg_Source
syms  h  b s n0 x1 x2 y1 y2 t M00 n M0ham k s1

assume(x1,'real')
assume(x2,'real')
assume(y1,'real')
assume(y2,'real')
assume(t,'real')
assume(x1,'positive')
assume(x2,'positive')
assume(y1,'positive')
assume(y2,'positive')


n0(x1,x2)=exp(-x1-x2);
k(x1,x2,y1,y2)=1;


R1(x1,x2,t)= -1/2.*(int(int(k(x1-y1,x2-y2,y1,y2).*n0(x1-y1,x2-y2).*n0(y1,y2),y2,[0,x2]),y1,[0,x1])) +(int(int(k(x1,x2,y1,y2).*n0(x1,x2).*n0(y1,y2),y2,[0,inf]),y1,[0,inf]))-exp(-x1-x2)

n1(x1,x2,t,h)=h.*int(R1(x1,x2,t),t,[0,t])

R2(x1,x2,t)=diff(n1(x1,x2,t,h),t)-1/2.*( int(int(k(x1-y1,x2-y2,y1,y2).*( n0(x1-y1,x2-y2).*n1(y1,y2,t,h)+n0(y1,y2).* n1(x1-y1,x2-y2,t,h)),y2,[0,x2]),y1,[0,x1])) +( int(int(k(x1,x2,y1,y2).*( n0(x1,x2).*n1(y1,y2,t,h)+n0(y1,y2).* n1(x1,x2,t,h)),y2,[0,inf]),y1,[0,inf]))

n2(x1,x2,t,h)=n1(x1,x2,t,h)+h.*int(R2(x1,x2,t),t,[0,t])


R3(x1,x2,t)=diff(n2(x1,x2,t,h),t)-1/2.*( int(int(k(x1-y1,x2-y2,y1,y2).*( n0(x1-y1,x2-y2).*n2(y1,y2,t,h)+  n1(x1-y1,x2-y2,t,h).*n1(y1,y2,t,h) +n0(y1,y2).* n2(x1-y1,x2-y2,t,h)),y2,[0,x2]),y1,[0,x1])) +(   int(int(k(x1,x2,y1,y2).*( n0(x1,x2).*n2(y1,y2,t,h)+ n1(x1,x2,t,h).*n1(y1,y2,t,h) +n0(y1,y2).* n2(x1,x2,t,h)),y2,[0,inf]),y1,[0,inf]))
n3(x1,x2,t,h)=n2(x1,x2,t,h)+h.*int(R3(x1,x2,t),t,[0,t])

R4(x1,x2,t)=diff(n3(x1,x2,t,h),t)-1/2.*( int(int(k(x1-y1,x2-y2,y1,y2).*( n0(x1-y1,x2-y2).*n3(y1,y2,t,h)+  n1(x1-y1,x2-y2,t,h).*n2(y1,y2,t,h)+  n2(x1-y1,x2-y2,t,h).*n1(y1,y2,t,h) +n0(y1,y2).* n3(x1-y1,x2-y2,t,h)),y2,[0,x2]),y1,[0,x1])) +(  int(int(k(x1,x2,y1,y2).*( n0(x1,x2).*n3(y1,y2,t,h)+ n1(x1,x2,t,h).*n2(y1,y2,t,h)+ n2(x1,x2,t,h).*n1(y1,y2,t,h)  +n0(y1,y2).* n3(x1,x2,t,h)),y2,[0,inf]),y1,[0,inf]))

n4(x1,x2,t,h)=n3(x1,x2,t,h)+h.*int(R4(x1,x2,t),t,[0,t])

R5(x1,x2,t)=diff(n4(x1,x2,t,h),t)-1/2.*(int(int(k(x1-y1,x2-y2,y1,y2).*( n0(x1-y1,x2-y2).*n4(y1,y2,t,h)+  n1(x1-y1,x2-y2,t,h).*n3(y1,y2,t,h)+  n2(x1-y1,x2-y2,t,h).*n2(y1,y2,t,h)+  n3(x1-y1,x2-y2,t,h).*n1(y1,y2,t,h) +n0(y1,y2).* n4(x1-y1,x2-y2,t,h)),y2,[0,x2]),y1,[0,x1])) +( int(int(k(x1,x2,y1,y2).*( n0(x1,x2).*n4(y1,y2,t,h)+ n1(x1,x2,t,h).*n3(y1,y2,t,h)+ n2(x1,x2,t,h).*n2(y1,y2,t,h)+ n3(x1,x2,t,h).*n1(y1,y2,t,h)  +n0(y1,y2).* n4(x1,x2,t,h)),y2,[0,inf]),y1,[0,inf]))

n5(x1,x2,t,h)=n4(x1,x2,t,h)+h.*int(R5(x1,x2,t),t,[0,t])
% 
% R6(x1,x2,t)=diff(n5(x1,x2,t,h),t)-int( int(s(y1,y2).*b(x1,x2,y1,y2).*n5(y1,y2,t,h),y1,[x1,inf]),y2,[x2,inf])+s(x1,x2).*n5(x1,x2,t,h)
% n6(x1,x2,t,h)=h.*int(R6(x1,x2,t),t,[0,t])




sol1(x1,x2,t,h)= n0(x1,x2)+ n1(x1,x2,t,h)+n2(x1,x2,t,h)+n3(x1,x2,t,h)+n4(x1,x2,t,h)%+n5(x1,x2,t,h)%+n6(x1,x2,t,h);


figure(1)
fplot(sol1(1,1,1,h),[-2,0.5], '-k*', 'LineWidth', 1, 'MarkerSize', 8)
xlabel('h')
ylabel('particle density')
grid on

% [xi,yi]= meshgrid(0:0.02:1);
% figure(2)
% mesh(xi,yi,sol1(xi,yi,1,-0.5),'FaceAlpha',0.8)
% xlabel('x1') 
% ylabel('x2')
% zlabel('particle density')




M00ham(t)= int(int(sol1(x1,x2,t,-0.5),x2,[0,inf]),x1,[0,inf])

M10ham(t)= int(int(x1.*sol1(x1,x2,t,-0.5),x2,[0,inf]),x1,[0,inf])

M01ham(t)= int(int(x2.*sol1(x1,x2,t,-0.5),x2,[0,inf]),x1,[0,inf])

M11ham(t)= int(int(x1.*x2.*sol1(x1,x2,t,-0.5),x2,[0,inf]),x1,[0,inf])

m1001(t)= int(int(x2.*sol1(x1,x2,t,-0.5)+x2.*sol1(x1,x2,t,-0.5),x2,[0,inf]),x1,[0,inf])



M00hpm(t)= int(int(sol1(x1,x2,t,-1),x2,[0,inf]),x1,[0,inf])

M10hpm(t)= int(int(x1.*sol1(x1,x2,t,-1),x2,[0,inf]),x1,[0,inf])

M01hpm(t)= int(int(x2.*sol1(x1,x2,t,-1),x2,[0,inf]),x1,[0,inf])

M11hpm(t)= int(int(x1.*x2.*sol1(x1,x2,t,-1),x2,[0,inf]),x1,[0,inf])


time_end        =   1;
TimeSteps       =   11;  
time            =   linspace(0, time_end, TimeSteps);

M00           =   M00ham(time);
M10           =   M10ham(time);
M01           =   M01ham(time);
M11           =   M11ham(time);

M00HPM           =   M00hpm(time);
M10HPM           =   M10hpm(time);
M01HPM           =   M01hpm(time);
M11HPM           =   M11hpm(time);

M_bar         = M11./M00;

M00_Exact     = 1+3.*time;
M11_Exact     = ones(size(time));

M_bar_Exact   = M11_Exact./M00_Exact;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data = xlsread('2D');
rawTable1 = readtable('2D','Sheet','AggSrc2D');
 
txl=rawTable1.time;
M00_CAT=rawTable1.m00;
M01_CAT=rawTable1.m01;
M11_CAT=rawTable1.m11;




figure(2)
plot(time, M00,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
hold on
plot(time, M00HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M00_CAT, 'b*', 'LineWidth', 1, 'MarkerSize', 9)
plot(time, M01, 'r+', 'LineWidth', 1, 'MarkerSize', 9)
plot(time,M01HPM, 'kpentagram', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M01_CAT,' bo','LineWidth', 1, 'MarkerSize', 9)
legend('HAM M00', 'HPM M00',' CAT M00', 'HAM M01', 'HPM M01',' CAT M01')
xlabel('dimensionless time')
ylabel('normalized moments')
grid on
hold off




figure(3)
plot(time, M11,'r^' ,'LineWidth', 1, 'MarkerSize', 9)
hold on
plot(time, M11HPM, 'kv', 'LineWidth', 1, 'MarkerSize', 9)
plot(txl, M11_CAT, 'b*', 'LineWidth', 1, 'MarkerSize', 9)
legend( 'HAM M11', 'HPM M11',' CAT M11')
xlabel('dimensionless time')
ylabel('normalized moments')
grid on
hold off


figure(5)
plot(time, M_bar_Exact, '-ks', 'LineWidth', 1, 'MarkerSize', 9)
hold on
plot(time, M_bar, '-b*','LineWidth', 1, 'MarkerSize', 9)
legend('Exact', 'HAM')
xlabel('dimensionless time')
ylabel('Average hypervolume')

